README


Compile with:
javac -classpath lib/:src src/main/Main.java

Execute with:
java -classpath lib/db2jcc4.jar:src/ main.Main

Compile&Execute:
javac -classpath lib/:src src/main/Main.java && java -classpath lib/db2jcc4.jar:src/ main.Main